import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { seed } from './seed.js';

const file = path.join(path.dirname(fileURLToPath(import.meta.url)), 'data.json');

// tiny JSON file store: zero native deps, so it installs on any laptop
function open() {
  try { return JSON.parse(fs.readFileSync(file, 'utf8')); } catch { return seed(); }
}
export const db = open();

let timer;
export function save() {
  clearTimeout(timer); // batch bursts of writes into one disk hit
  timer = setTimeout(() => fs.writeFile(file, JSON.stringify(db, null, 1), () => {}), 150);
}
save();
