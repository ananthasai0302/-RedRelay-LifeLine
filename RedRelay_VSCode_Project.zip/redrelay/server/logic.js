// All the clinical + geo rules live here so they are easy to test and explain.
export const DAY = 864e5;
export const LOCK_DAYS = 90;

export const GROUPS = ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'];

// who each donor group can give red cells to
const GIVES = {
  'O-': GROUPS,
  'O+': ['O+', 'A+', 'B+', 'AB+'],
  'A-': ['A-', 'A+', 'AB-', 'AB+'],
  'A+': ['A+', 'AB+'],
  'B-': ['B-', 'B+', 'AB-', 'AB+'],
  'B+': ['B+', 'AB+'],
  'AB-': ['AB-', 'AB+'],
  'AB+': ['AB+'],
};
export const canGive = (donor, patient) => (GIVES[donor] || []).includes(patient);
export const donorGroupsFor = (patient) => GROUPS.filter((g) => canGive(g, patient));

export const PLACES = [
  ['banjara', 'Banjara Hills', 'Hyderabad', 17.4156, 78.4347],
  ['jubilee', 'Jubilee Hills', 'Hyderabad', 17.4326, 78.4071],
  ['madhapur', 'Madhapur', 'Hyderabad', 17.4486, 78.3908],
  ['gachibowli', 'Gachibowli', 'Hyderabad', 17.4401, 78.3489],
  ['kondapur', 'Kondapur', 'Hyderabad', 17.46, 78.357],
  ['kukatpally', 'Kukatpally', 'Hyderabad', 17.4948, 78.3996],
  ['ameerpet', 'Ameerpet', 'Hyderabad', 17.4375, 78.4483],
  ['secunderabad', 'Secunderabad', 'Hyderabad', 17.4399, 78.4983],
  ['begumpet', 'Begumpet', 'Hyderabad', 17.444, 78.4676],
  ['uppal', 'Uppal', 'Hyderabad', 17.4058, 78.5591],
  ['dilsukhnagar', 'Dilsukhnagar', 'Hyderabad', 17.3688, 78.5247],
  ['lbnagar', 'LB Nagar', 'Hyderabad', 17.3457, 78.5522],
  ['mehdipatnam', 'Mehdipatnam', 'Hyderabad', 17.393, 78.441],
  ['charminar', 'Charminar', 'Hyderabad', 17.3616, 78.4747],
  ['miyapur', 'Miyapur', 'Hyderabad', 17.4969, 78.3548],
  ['koramangala', 'Koramangala', 'Bengaluru', 12.9352, 77.6245],
  ['indiranagar', 'Indiranagar', 'Bengaluru', 12.9784, 77.6408],
  ['whitefield', 'Whitefield', 'Bengaluru', 12.9698, 77.75],
  ['jayanagar', 'Jayanagar', 'Bengaluru', 12.925, 77.5938],
].map(([id, name, city, lat, lng]) => ({ id, name, city, lat, lng }));

export const HOSPITALS = [
  ['apollo', 'Apollo Hospital, Jubilee Hills', 'Hyderabad', 17.4175, 78.4116],
  ['yashoda', 'Yashoda Hospital, Secunderabad', 'Hyderabad', 17.4416, 78.4957],
  ['kims', 'KIMS Hospital, Kondapur', 'Hyderabad', 17.4686, 78.3646],
  ['care', 'Care Hospital, Banjara Hills', 'Hyderabad', 17.4175, 78.45],
  ['gandhi', 'Gandhi Hospital, Musheerabad', 'Hyderabad', 17.4245, 78.497],
  ['nims', 'NIMS, Punjagutta', 'Hyderabad', 17.4256, 78.451],
  ['manipal', 'Manipal Hospital, Old Airport Rd', 'Bengaluru', 12.9585, 77.6485],
].map(([id, name, city, lat, lng]) => ({ id, name, city, lat, lng }));

// haversine, good enough for "how far is the donor"
export function km(a, b) {
  const rad = (x) => (x * Math.PI) / 180;
  const dLat = rad(b.lat - a.lat);
  const dLng = rad(b.lng - a.lng);
  const h = Math.sin(dLat / 2) ** 2 + Math.cos(rad(a.lat)) * Math.cos(rad(b.lat)) * Math.sin(dLng / 2) ** 2;
  return 6371 * 2 * Math.asin(Math.sqrt(h));
}

export const isLocked = (d) => !!d.lastDonation && Date.now() - d.lastDonation < LOCK_DAYS * DAY;
export const unlockOn = (d) => (d.lastDonation ? d.lastDonation + LOCK_DAYS * DAY : null);

export const maskPhone = (p = '') => {
  const digits = p.replace(/\D/g, '');
  return digits.length < 6 ? '••••' : `+91 ${digits.slice(-10, -8)}••• ••${digits.slice(-3)}`;
};

const initialsOf = (name) => name.trim().split(/\s+/).map((w) => w[0].toUpperCase()).join('.') + '.';

// the only shape of a donor that ever leaves the server: no name, no phone
export function maskDonor(d) {
  const p = PLACES.find((x) => x.id === d.placeId) || PLACES[0];
  return {
    id: d.id, initials: initialsOf(d.name), bloodGroup: d.bloodGroup,
    locality: p.name, city: p.city, lat: p.lat, lng: p.lng,
    available: d.available, locked: isLocked(d), unlockOn: unlockOn(d),
  };
}

export function summarize(r) {
  const committed = r.responses.reduce((s, x) => s + x.units, 0);
  const expired = !r.closedAt && Date.now() > r.expiresAt;
  let status = 'open';
  if (r.closedAt || expired) status = 'closed';
  else if (committed >= r.units) status = 'fulfilled';
  else if (committed > 0) status = 'responded';
  const { doctorContact, responses, ...rest } = r;
  return {
    ...rest, status, committed, remaining: Math.max(0, r.units - committed),
    doctorMasked: maskPhone(doctorContact),
    closedReason: r.closedAt ? 'received' : expired ? 'expired' : null,
    hospital: HOSPITALS.find((h) => h.id === r.hospitalId),
    responderIds: responses.map((x) => x.donorId),
    compatibleGroups: donorGroupsFor(r.bloodGroup),
  };
}
