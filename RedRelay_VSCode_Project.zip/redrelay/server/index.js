import express from 'express';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { db, save } from './store.js';
import { GROUPS, HOSPITALS, PLACES, LOCK_DAYS, canGive, km, isLocked, maskDonor, summarize } from './logic.js';

const app = express();
app.use(express.json());

const phoneOk = (p) => /^\+?[\d\s-]{10,15}$/.test(p || '');
const findReq = (id) => db.requests.find((r) => r.id === id);

function eligibleDonors(r, radius) {
  const h = HOSPITALS.find((x) => x.id === r.hospitalId);
  return db.donors
    .filter((d) => canGive(d.bloodGroup, r.bloodGroup) && d.available && !isLocked(d))
    .map((d) => {
      const m = maskDonor(d);
      const distanceKm = +km(h, m).toFixed(1);
      return { ...m, distanceKm, etaMin: Math.round((distanceKm / 22) * 60) + 4 }; // ~22 km/h city traffic
    })
    .filter((d) => d.distanceKm <= radius)
    .sort((a, b) => a.distanceKm - b.distanceKm);
}

app.get('/api/meta', (_q, res) => res.json({ groups: GROUPS, hospitals: HOSPITALS, places: PLACES, lockDays: LOCK_DAYS }));

app.get('/api/requests', (_q, res) => {
  const list = db.requests.map(summarize);
  list.sort((a, b) => (a.status === 'closed') - (b.status === 'closed') || a.expiresAt - b.expiresAt);
  res.json(list);
});

app.post('/api/requests', (req, res) => {
  const b = req.body || {};
  const units = Number(b.units), hours = Number(b.hours);
  const errors = {};
  if (!b.patientName || b.patientName.trim().length < 2) errors.patientName = 'Enter the patient name';
  if (!GROUPS.includes(b.bloodGroup)) errors.bloodGroup = 'Pick a blood group';
  if (!HOSPITALS.some((h) => h.id === b.hospitalId)) errors.hospitalId = 'Pick a hospital';
  if (!(units >= 1 && units <= 10)) errors.units = 'Enter 1 to 10 units';
  if (!(hours >= 1 && hours <= 24)) errors.hours = 'Deadline must be between 1 and 24 hours';
  if (!phoneOk(b.doctorContact)) errors.doctorContact = "Enter the doctor's phone number";
  if (Object.keys(errors).length) return res.status(400).json({ error: 'Some fields need fixing', errors });

  const now = Date.now();
  const r = {
    id: 'r' + now.toString(36), patientName: b.patientName.trim(), bloodGroup: b.bloodGroup, units,
    hospitalId: b.hospitalId, doctorContact: b.doctorContact, reason: (b.reason || '').slice(0, 140),
    createdAt: now, expiresAt: now + hours * 3600000, closedAt: null, responses: [],
  };
  db.requests.unshift(r);
  save();
  res.status(201).json(summarize(r));
});

app.get('/api/requests/:id', (req, res) => {
  const r = findReq(req.params.id);
  if (!r) return res.status(404).json({ error: 'Request not found' });
  const radius = Math.min(Number(req.query.radius) || 15, 100);
  res.json({ ...summarize(r), eligible: eligibleDonors(r, radius), radius });
});

app.post('/api/requests/:id/respond', (req, res) => {
  const r = findReq(req.params.id);
  if (!r) return res.status(404).json({ error: 'Request not found' });
  const s = summarize(r);
  if (s.status === 'closed') return res.status(409).json({ error: 'This request is closed' });
  if (s.status === 'fulfilled') return res.status(409).json({ error: 'Enough donors have already committed' });
  const d = db.donors.find((x) => x.id === req.body?.donorId);
  if (!d) return res.status(404).json({ error: 'Register as a donor first' });
  if (!canGive(d.bloodGroup, r.bloodGroup)) return res.status(400).json({ error: `${d.bloodGroup} blood can't be given to a ${r.bloodGroup} patient` });
  if (!d.available) return res.status(400).json({ error: 'You are marked unavailable. Turn availability on first' });
  if (isLocked(d)) return res.status(400).json({ error: `You donated recently. You can donate again after ${new Date(d.lastDonation + LOCK_DAYS * 864e5).toLocaleDateString('en-IN')}` });
  if (r.responses.some((x) => x.donorId === d.id)) return res.status(409).json({ error: 'You already responded to this request' });
  const units = Math.min(Math.max(1, Number(req.body.units) || 1), s.remaining);
  r.responses.push({ donorId: d.id, units, at: Date.now() });
  save();
  res.json(summarize(r));
});

// family confirms blood arrived: closes the request and starts the 90 day lock for everyone who gave
app.post('/api/requests/:id/received', (req, res) => {
  const r = findReq(req.params.id);
  if (!r) return res.status(404).json({ error: 'Request not found' });
  if (summarize(r).status === 'closed') return res.status(409).json({ error: 'Already closed' });
  r.closedAt = Date.now();
  r.responses.forEach((x) => { const d = db.donors.find((y) => y.id === x.donorId); if (d) d.lastDonation = r.closedAt; });
  save();
  res.json(summarize(r));
});

app.get('/api/donors', (req, res) => {
  const { city, group } = req.query;
  res.json(db.donors.map(maskDonor).filter((d) => (!city || d.city === city) && (!group || d.bloodGroup === group)));
});

// a donor can see their own full name, but never anyone's phone
app.get('/api/donors/:id', (req, res) => {
  const d = db.donors.find((x) => x.id === req.params.id);
  if (!d) return res.status(404).json({ error: 'Donor not found' });
  res.json({ ...maskDonor(d), name: d.name, lastDonation: d.lastDonation });
});

app.post('/api/donors', (req, res) => {
  const b = req.body || {};
  const errors = {};
  if (!b.name || b.name.trim().length < 2) errors.name = 'Enter your name';
  if (!phoneOk(b.phone)) errors.phone = 'Enter a valid phone number';
  if (!GROUPS.includes(b.bloodGroup)) errors.bloodGroup = 'Pick your blood group';
  if (!PLACES.some((p) => p.id === b.placeId)) errors.placeId = 'Pick your locality';
  if (!errors.phone && db.donors.some((d) => d.phone.replace(/\D/g, '') === b.phone.replace(/\D/g, ''))) errors.phone = 'This number is already registered';
  if (Object.keys(errors).length) return res.status(400).json({ error: 'Some fields need fixing', errors });
  const d = { id: 'd' + Date.now().toString(36), name: b.name.trim(), phone: b.phone, bloodGroup: b.bloodGroup, placeId: b.placeId, available: true, lastDonation: null };
  db.donors.push(d);
  save();
  res.status(201).json({ ...maskDonor(d), name: d.name });
});

app.patch('/api/donors/:id', (req, res) => {
  const d = db.donors.find((x) => x.id === req.params.id);
  if (!d) return res.status(404).json({ error: 'Donor not found' });
  d.available = !!req.body.available;
  save();
  res.json(maskDonor(d));
});

// relay ping: the family reaches a donor without ever seeing a number
app.post('/api/relay', (req, res) => {
  const d = db.donors.find((x) => x.id === req.body?.donorId);
  if (!d) return res.status(404).json({ error: 'Donor not found' });
  db.pings = (db.pings || 0) + 1;
  save();
  res.json({ ok: true });
});

const dist = path.join(path.dirname(fileURLToPath(import.meta.url)), '../client/dist');
if (fs.existsSync(dist)) {
  app.use(express.static(dist));
  app.get('*', (_q, res) => res.sendFile(path.join(dist, 'index.html')));
}

const port = process.env.PORT || 5000;
app.listen(port, () => console.log(`RedRelay API on http://localhost:${port}`));
