import { PLACES, DAY } from './logic.js';

const names = ['Sai Kiran', 'Ananya Reddy', 'Mohammed Irfan', 'Priya Nair', 'Rahul Verma', 'Sneha Kulkarni',
  'Arjun Rao', 'Fatima Begum', 'Vikram Singh', 'Lakshmi Devi', 'Karthik Naidu', 'Divya Menon',
  'Imran Khan', 'Meera Iyer', 'Rohit Sharma', 'Harika Chowdary', 'Naveen Kumar', 'Swathi Pillai',
  'Abdul Rahman', 'Pooja Agarwal', 'Teja Varma', 'Nisha Thomas', 'Sandeep Goud', 'Bhavana Rao',
  'Yusuf Ali', 'Keerthi Reddy', 'Manoj Gowda', 'Deepa Hegde', 'Suresh Babu', 'Aisha Siddiqui'];
const groups = ['O+', 'B+', 'A+', 'O+', 'B+', 'O-', 'A+', 'B-', 'O+', 'AB+', 'B+', 'A-', 'O+', 'B+', 'A+',
  'O-', 'AB-', 'B+', 'O+', 'A+', 'B+', 'O+', 'A-', 'B-', 'O-', 'AB+', 'A+', 'O+', 'B+', 'A+'];

export function seed() {
  const now = Date.now();
  const donors = names.map((name, i) => ({
    id: 'd' + (i + 1), name, bloodGroup: groups[i],
    phone: '9848' + String(100000 + i * 3719).slice(0, 6),
    // first 26 around Hyderabad, last 4 in Bengaluru so the city filter has something to do
    placeId: i < 26 ? PLACES[i % 15].id : PLACES[15 + (i - 26)].id,
    available: i % 7 !== 3,
    lastDonation: i === 5 ? now - 20 * DAY : i === 11 ? now - 85 * DAY : null,
  }));
  const mk = (id, patientName, bloodGroup, units, hospitalId, hours, ago, doctorContact, responses = []) => ({
    id, patientName, bloodGroup, units, hospitalId, doctorContact, responses,
    reason: '', createdAt: now - ago * 60000, expiresAt: now - ago * 60000 + hours * 3600000,
    closedAt: null,
  });
  const requests = [
    mk('r1', 'Ramesh K', 'B+', 2, 'apollo', 4, 20, '+91 9876501234', [{ donorId: 'd5', units: 1, at: now - 600000 }]),
    mk('r2', 'Sunita D', 'O-', 3, 'yashoda', 3, 45, '+91 9812345670'),
    mk('r3', 'Baby of Anitha', 'A+', 1, 'kims', 6, 90, '+91 9900112233'),
    mk('r4', 'Faizan M', 'AB-', 2, 'care', 12, 15, '+91 9700011122'),
    mk('r5', 'Lakshmi P', 'B-', 2, 'gandhi', 5, 120, '+91 9000099887', [{ donorId: 'd8', units: 2, at: now - 900000 }]),
  ];
  return { donors, requests, pings: 0 };
}
